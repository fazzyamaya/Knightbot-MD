
require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")
//========== Setting Owner ==========//
global.owner = "6287878064688"
global.owner2 = "GANTI NOMER KALIAN"
global.namaowner = "Yukina Hiiragi"
global.botname = "Lucifer Fallen 🪽"
//======== Setting Bot & Link ========//
global.namabot = "Lucifer Fallen 🪽" 
global.namabot2 = "Lucifer Fallen 🪽"
global.foother = "𝘓𝘶𝘤𝘪𝘧𝘦𝘳-𝘐𝘴-𝘏𝘦𝘳𝘦™"
global.versibot = "3.0"
global.idsaluran = false
global.linkgc = 'https://chat.whatsapp.com/HJQCrGNThgN2Ko3R6nJeRB'
global.linksaluran = "https://whatsapp.com/channel/0029VaoF3P2Elah1jmqLIn1j"
global.linkyt = 'no youtube'
global.linktele = 'https://t.me/YukinaDevils'
global.packname = "Lucifer Fallen 🪽"
global.author = "Lucifer Fallen 🪽"

//========== Setting Event ==========//
global.welcome = true
global.autoread = false
global.anticall = true
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = ""
global.apikey = ""
global.capikey = ""
//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "𝚂𝚘𝚛𝚛𝚢 𝚝𝚑𝚎𝚛𝚎 𝚒𝚜 𝚎𝚛𝚘𝚛 𝚐𝚘𝚒𝚗𝚐 𝚘𝚗 ...",
"done": "𝚂𝚞𝚌𝚌𝚎𝚜 🪽", 
"wait": "𝙿𝚕𝚜 𝚆𝚊𝚒𝚝 𝙻𝚞𝚌𝚒𝚏𝚎𝚛 𝚒𝚜 𝙾𝚗 𝙿𝚛𝚘𝚜𝚎𝚜 . . .", 
"group": "𝚂𝚘𝚛𝚛𝚢 𝚃𝚑𝚒𝚜 𝙵𝚎𝚊𝚝𝚞𝚛𝚎𝚜 𝙸𝚜 𝚘𝚗𝚕𝚢 𝚌𝚊𝚗 𝚋𝚎 𝚞𝚜𝚎𝚍 𝚘𝚗 𝚌𝚑𝚊𝚝 𝚐𝚛𝚘𝚞𝚙𝚜!!!", 
"private": "𝚂𝚘𝚛𝚛𝚢 𝚃𝚑𝚒𝚜 𝙵𝚎𝚊𝚝𝚞𝚛𝚎𝚜 𝙸𝚜 𝙾𝚗𝚕𝚢 𝚌𝚊𝚗 𝚋𝚎 𝚞𝚜𝚎𝚍 𝚘𝚗 𝙿𝚛𝚒𝚟𝚊𝚝𝚎 𝙲𝚑𝚊𝚝𝚜!!!", 
"admin": "𝚂𝚘𝚛𝚛𝚢 𝚈𝚘𝚞𝚛 𝚗𝚘𝚝 𝚊𝚗 𝙰𝚍𝚖𝚒𝚗", 
"adminbot": "𝚂𝚘𝚛𝚛𝚢 𝚃𝚑𝚒𝚜 𝙱𝚘𝚝 𝚘𝚗𝚕𝚢 𝚌𝚊𝚗 𝚋𝚎 𝚞𝚜𝚎𝚍 𝚆𝚑𝚎𝚗 𝚋𝚘𝚝 𝙸𝚜 𝚊𝚗 𝙰𝚍𝚖𝚒𝚗", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "𝚆𝚑𝚘 𝚍𝚘 𝚢𝚘𝚞 𝚝𝚑𝚒𝚗𝚔 𝚢𝚘𝚞 𝚊𝚛𝚎? 𝚢𝚘𝚞𝚛 𝚗𝚘𝚝 𝚖𝚢 𝚌𝚛𝚎𝚊𝚝𝚘𝚛", 
"premium": "𝚈𝚘𝚞 𝚊𝚛𝚎 𝚊 𝚕𝚘𝚠𝚕𝚢 𝚌𝚕𝚊𝚜𝚜 𝚢𝚘𝚞 𝚊𝚛𝚎 𝚗𝚘𝚝 𝚙𝚛𝚎𝚖𝚒𝚞𝚖 𝚊𝚍𝚍𝚙𝚛𝚎𝚖𝚒𝚞𝚖 𝚘𝚗 𝚝𝚑𝚎 𝚋𝚘𝚝 𝚘𝚛 𝚊𝚜𝚔 𝘠𝘶𝘬𝘪𝘯𝘢-𝘏𝘪𝘳𝘢𝘨𝘪𝘪 𝚝𝚘 𝚊𝚍𝚍"

}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})